package com.castrosafio.bosscontroller;

import com.castrosafio.bosscontroller.network.BossNetwork;
import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;

@Mod(CastroSafioBossController.MODID)
public final class CastroSafioBossController {
    public static final String MODID = "castrosafiobosscontroller";
    public static final Logger LOGGER = LogUtils.getLogger();

    public CastroSafioBossController(IEventBus modBus, ModContainer container) {
        modBus.addListener(BossNetwork::registerPayloads);
        LOGGER.info("CastroSafio Boss Controller cargado");
    }
}
