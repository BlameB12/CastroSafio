package com.castrosafio.bosscontroller.network;

import com.castrosafio.bosscontroller.CastroSafioBossController;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record BossInputPayload(float forward, float strafe, int flags, float yaw, float pitch)
        implements CustomPacketPayload {

    public static final int FLAG_JUMP = 1;
    public static final int FLAG_DESCEND = 2;
    public static final int FLAG_SPRINT = 4;

    public static final Type<BossInputPayload> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(CastroSafioBossController.MODID, "boss_input")
    );

    public static final StreamCodec<ByteBuf, BossInputPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.FLOAT, BossInputPayload::forward,
            ByteBufCodecs.FLOAT, BossInputPayload::strafe,
            ByteBufCodecs.VAR_INT, BossInputPayload::flags,
            ByteBufCodecs.FLOAT, BossInputPayload::yaw,
            ByteBufCodecs.FLOAT, BossInputPayload::pitch,
            BossInputPayload::new
    );

    public boolean jump() {
        return (flags & FLAG_JUMP) != 0;
    }

    public boolean descend() {
        return (flags & FLAG_DESCEND) != 0;
    }

    public boolean sprint() {
        return (flags & FLAG_SPRINT) != 0;
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
