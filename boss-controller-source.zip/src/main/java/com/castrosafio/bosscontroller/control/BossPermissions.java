package com.castrosafio.bosscontroller.control;

import com.castrosafio.bosscontroller.CastroSafioBossController;
import net.minecraft.server.level.ServerPlayer;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class BossPermissions {
    private static final Path FILE = Path.of("config", "castrosafio-boss-controller-allowed.txt");
    private static final Set<UUID> ALLOWED = new HashSet<>();

    private BossPermissions() {}

    public static void load() {
        ALLOWED.clear();
        try {
            if (!Files.exists(FILE)) {
                Files.createDirectories(FILE.getParent());
                return;
            }
            for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
                String cleaned = line.trim();
                if (cleaned.isEmpty() || cleaned.startsWith("#")) continue;
                try {
                    ALLOWED.add(UUID.fromString(cleaned));
                } catch (IllegalArgumentException ignored) {
                    CastroSafioBossController.LOGGER.warn("UUID inválido en {}: {}", FILE, cleaned);
                }
            }
        } catch (IOException e) {
            CastroSafioBossController.LOGGER.error("No se pudo cargar la lista de permisos", e);
        }
    }

    public static boolean canControl(ServerPlayer player) {
        return player.createCommandSourceStack().hasPermission(2) || ALLOWED.contains(player.getUUID());
    }

    public static void allow(ServerPlayer player) {
        ALLOWED.add(player.getUUID());
        save();
    }

    public static void deny(ServerPlayer player) {
        ALLOWED.remove(player.getUUID());
        save();
    }

    private static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            List<String> lines = ALLOWED.stream().map(UUID::toString).sorted().toList();
            Files.write(FILE, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            CastroSafioBossController.LOGGER.error("No se pudo guardar la lista de permisos", e);
        }
    }
}
