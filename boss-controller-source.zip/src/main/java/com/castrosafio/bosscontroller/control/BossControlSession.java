package com.castrosafio.bosscontroller.control;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

import java.util.UUID;

public record BossControlSession(
        UUID playerId,
        UUID targetId,
        ResourceKey<Level> levelKey,
        UUID seatId,
        boolean targetNoAiBefore,
        boolean playerInvisibleBefore,
        boolean playerInvulnerableBefore
) {}
