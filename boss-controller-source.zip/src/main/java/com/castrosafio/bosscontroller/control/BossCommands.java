package com.castrosafio.bosscontroller.control;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

public final class BossCommands {
    private BossCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("bosscontrol")
                .then(Commands.literal("allow")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> allow(ctx.getSource(), EntityArgument.getPlayer(ctx, "player")))))
                .then(Commands.literal("deny")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(ctx -> deny(ctx.getSource(), EntityArgument.getPlayer(ctx, "player")))))
                .then(Commands.literal("take")
                        .then(Commands.argument("entity", EntityArgument.entity())
                                .executes(ctx -> take(ctx.getSource(), EntityArgument.getEntity(ctx, "entity")))))
                .then(Commands.literal("force")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("entity", EntityArgument.entity())
                                        .executes(ctx -> force(ctx.getSource(),
                                                EntityArgument.getPlayer(ctx, "player"),
                                                EntityArgument.getEntity(ctx, "entity"))))))
                .then(Commands.literal("stop")
                        .executes(ctx -> stopSelf(ctx.getSource()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .requires(source -> source.hasPermission(2))
                                .executes(ctx -> stopOther(ctx.getSource(), EntityArgument.getPlayer(ctx, "player")))))
                .then(Commands.literal("status")
                        .executes(ctx -> status(ctx.getSource()))));
    }

    private static int allow(CommandSourceStack source, ServerPlayer player) {
        BossPermissions.allow(player);
        source.sendSuccess(() -> Component.literal("Permiso de controlador concedido a ")
                .append(player.getDisplayName()).withStyle(ChatFormatting.GREEN), true);
        return 1;
    }

    private static int deny(CommandSourceStack source, ServerPlayer player) {
        BossPermissions.deny(player);
        BossControlManager.stop(player, true);
        source.sendSuccess(() -> Component.literal("Permiso de controlador retirado a ")
                .append(player.getDisplayName()).withStyle(ChatFormatting.YELLOW), true);
        return 1;
    }

    private static int take(CommandSourceStack source, Entity entity) {
        ServerPlayer player;
        try {
            player = source.getPlayerOrException();
        } catch (Exception e) {
            source.sendFailure(Component.literal("Este comando debe ejecutarlo un jugador."));
            return 0;
        }
        if (!BossPermissions.canControl(player)) {
            source.sendFailure(Component.literal("No tenés permiso para controlar jefes."));
            return 0;
        }
        Component result = BossControlManager.start(player, entity);
        player.sendSystemMessage(result);
        return 1;
    }

    private static int force(CommandSourceStack source, ServerPlayer player, Entity entity) {
        Component result = BossControlManager.start(player, entity);
        player.sendSystemMessage(result);
        source.sendSuccess(() -> Component.literal("Intento de control aplicado a ").append(player.getDisplayName()), false);
        return 1;
    }

    private static int stopSelf(CommandSourceStack source) {
        try {
            ServerPlayer player = source.getPlayerOrException();
            BossControlManager.stop(player, true);
            return 1;
        } catch (Exception e) {
            source.sendFailure(Component.literal("Este comando debe ejecutarlo un jugador o indicar un jugador."));
            return 0;
        }
    }

    private static int stopOther(CommandSourceStack source, ServerPlayer player) {
        BossControlManager.stop(player, true);
        source.sendSuccess(() -> Component.literal("Control detenido para ").append(player.getDisplayName()), true);
        return 1;
    }

    private static int status(CommandSourceStack source) {
        try {
            ServerPlayer player = source.getPlayerOrException();
            if (BossControlManager.isControlling(player)) {
                var target = BossControlManager.getControlledTarget(player);
                source.sendSuccess(() -> Component.literal("Control activo: ")
                        .append(target == null ? Component.literal("entidad no disponible") : target.getDisplayName()), false);
            } else {
                source.sendSuccess(() -> Component.literal("No estás controlando ningún jefe."), false);
            }
            return 1;
        } catch (Exception e) {
            source.sendFailure(Component.literal("Este comando debe ejecutarlo un jugador."));
            return 0;
        }
    }
}
