# CastroSafio Boss Controller

BETA 0.1.0 para Minecraft 1.21.1 + NeoForge.

## Comandos
- `/bosscontrol allow <jugador>` - OP: autoriza a un jugador.
- `/bosscontrol deny <jugador>` - OP: quita autorización.
- `/bosscontrol take <entidad>` - jugador autorizado: controla una entidad viva.
- `/bosscontrol force <jugador> <entidad>` - OP: fuerza control para otro jugador.
- `/bosscontrol stop` - deja de controlar.
- `/bosscontrol stop <jugador>` - OP: detiene a otro jugador.
- `/bosscontrol status` - muestra el estado actual.

## Controles
- W/A/S/D: movimiento del jefe relativo a la cámara.
- Espacio: salto / subir en agua o entidades sin gravedad.
- Shift: bajar en agua/entidades sin gravedad. No desmonta durante el control.
- Ctrl: velocidad rápida.
- Mouse: cámara libre.

## Nota de esta BETA
Esta versión prioriza movimiento, cámara y permisos. Las habilidades específicas de cada jefe se agregan como adaptadores en versiones siguientes.
